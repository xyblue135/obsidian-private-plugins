# Mirror Attachments v1.6.6

作者：**xyblue135**

Mirror Attachments 用于让 `Notes` 与 `Attachments` 保持一对一镜像目录，并统一处理系统文件的粘贴、拖入、命名与 Markdown 链接。

## v1.6.6：智能附件命名 + 批量导入优化

这一版不再把所有附件都强制改成时间戳，而是按“是否嵌入正文”自动选择更合适的命名方式。

### 1. 嵌入式资源：时间戳命名

图片与 PDF 继续使用毫秒级时间戳：

```text
20260812151230001.png
20260812151230002.pdf
```

Markdown 使用 `![]()`：

```md
![](/Attachments/A/B/文章/20260812151230001.png)
![](/Attachments/A/B/文章/20260812151230002.pdf)
```

这样截图、剪贴板图片等不会产生大量 `image.png`、`image (1).png`。

### 2. 非嵌入式附件：保留原文件名

ZIP、RAR、7Z、Office 文档和其他普通附件保留原名：

```text
项目源码.zip
毕业论文.docx
实验数据.xlsx
```

Markdown 使用普通链接 `[]()`，并显示完整文件名和扩展名：

```md
[项目源码.zip](/Attachments/A/B/文章/项目源码.zip)
[毕业论文.docx](/Attachments/A/B/文章/毕业论文.docx)
[实验数据.xlsx](/Attachments/A/B/文章/实验数据.xlsx)
```

### 3. 重名自动处理

目标目录已经存在同名普通附件时，不覆盖、不弹窗，自动使用：

```text
项目源码.zip
项目源码 (1).zip
项目源码 (2).zip
```

插件会提示实际保存后的文件名。

### 4. 文件名安全处理

普通附件尽量保留用户原始名称，仅处理跨平台文件系统容易出问题的内容：

- 替换 Windows 非法字符：`\\ / : * ? " < > |`
- 清理 ASCII 控制字符
- 清理文件名末尾的句点或空格
- 处理 `CON`、`PRN`、`AUX`、`NUL`、`COM1`～`COM9`、`LPT1`～`LPT9` 等 Windows 保留设备名
- 中文、正常空格、括号等可读信息尽量保留

例如：

```text
项目:最终版?.zip
→ 项目-最终版-.zip
```

### 5. 批量粘贴与错误处理

一次复制多个附件时：

- 每个 Markdown 链接之间自动留一个空行，阅读和后续编辑更清楚。
- 某一个文件保存失败，不会中断同批次其他附件。
- 重名、失败、成功数量都会给出明确提示。

例如：

```md
![](/Attachments/A/B/文章/20260812151230001.png)

[项目源码.zip](/Attachments/A/B/文章/项目源码.zip)

[实验数据.xlsx](/Attachments/A/B/文章/实验数据.xlsx)
```

## 固定目录规则

插件固定维护：

```text
Notes/A/B/文章.md
↕
Attachments/A/B/文章/
```

即使文章没有附件，也会建立对应空目录。

插件会在以下时机维护一对一关系：

- 插件加载后扫描并补建缺失目录
- 新建 Markdown 时建立附件目录
- Markdown 改名/移动时同步迁移附件目录
- 删除 Markdown 时按 Obsidian 回收站设置处理对应附件目录
- 设置页可重新校验并自动纠错安全可确定的问题

## Windows 文件复制兼容

从 Windows 文件资源管理器 `Ctrl+C` ZIP、Office、PDF 等文件，再到 Obsidian `Ctrl+V` 时，Electron 有时只在 `clipboardData.items` 中暴露文件。

插件同时读取：

```text
clipboardData.files
clipboardData.items
```

并自动去重，因此 ZIP 等普通附件也能正常粘贴。

## Markdown 规则总览

| 类型 | 保存名称 | Markdown |
|---|---|---|
| PNG / JPG / JPEG / GIF / WebP / BMP / SVG / AVIF | 时间戳 | `![]()` |
| PDF | 时间戳 | `![]()` |
| ZIP / RAR / 7Z | 原文件名 | `[]()` |
| DOC / DOCX | 原文件名 | `[]()` |
| XLS / XLSX | 原文件名 | `[]()` |
| PPT / PPTX | 原文件名 | `[]()` |
| 其他普通附件 | 原文件名 | `[]()` |

所有链接使用 Vault 根目录绝对路径，例如：

```text
/Attachments/A/B/文章/...
```

## 设置面板

设置页按照实际使用流程排列：

1. 存储结构
2. 导入行为
3. 命名与 Markdown 规则
4. 目录一致性
5. 快捷操作

其中“命名与 Markdown 规则”会直接展示嵌入式资源和普通附件各自的命名、扩展名范围与示例。

## 文件树快捷操作

左侧文件树右键受管理的 Markdown：

```text
📂 打开对应附件目录
```

即可定位到当前文章的一对一附件目录。

## 版本变化摘要

### v1.6.6

- 非嵌入式附件保留原始文件名。
- 重名自动追加 `(1)`、`(2)`……
- 增加非法字符和 Windows 保留设备名处理。
- 普通附件 Markdown 显示完整文件名及扩展名。
- 多附件之间自动空一行。
- 单文件失败不再中断整批导入，并优化提示。
- 设置页同步升级为“智能命名”规则说明。

### v1.6.5

- 图片与 PDF 使用 `![]()`；ZIP、Office 等普通附件使用 `[]()`。
- 重构设置页信息结构和规则卡片。

### v1.6.4

- 修复 Windows 复制 ZIP/普通文件后部分环境无法粘贴的问题。
- 同时读取 `DataTransfer.files` 与 `DataTransfer.items`。

### v1.6.2

- 文件树右键 Markdown 可快速打开对应附件目录。

### v1.6.1

- Markdown 链接改为 Vault 根目录绝对路径。
- 图片 alt 固定为空。
